
class TextScaler {
  final double scale;

  const TextScaler(this.scale);

  double operator [](double fontSize) => fontSize * scale;

  static const linear = TextScaler(1);
}
