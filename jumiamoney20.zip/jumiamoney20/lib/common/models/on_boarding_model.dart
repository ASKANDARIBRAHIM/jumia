class OnboardModel{
  final String image;
  final String backgroundImage;
  final String title;
  final String subtitle;
  OnboardModel(this.image, this.backgroundImage, this.title, this.subtitle);
}